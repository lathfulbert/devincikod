<?php

namespace App\Core\Support;

class DotEnv
{
    public function __construct(protected string $path)
    {
    }

    public function load(): void
    {
        if (!file_exists($this->path)) {
            return;
        }

        $lines = file($this->path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        foreach ($lines as $line) {
            if (strpos(trim($line), '#') === 0) {
                continue;
            }

            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);

            // Set environment variables, overwriting empty values
            $shouldSet = !array_key_exists($name, $_SERVER) || empty($_SERVER[$name]);
            $shouldSet = $shouldSet || (!array_key_exists($name, $_ENV) || empty($_ENV[$name]));

            if ($shouldSet) {
                putenv(sprintf('%s=%s', $name, $value));
                $_ENV[$name] = $value;
                $_SERVER[$name] = $value;
            }
        }
    }
}
