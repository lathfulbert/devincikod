<?php

namespace Modules\Settings\Models;

use App\Core\Database\Model;
use App\Core\Database\Traits\HasAuthor;

class SmsGateway extends Model
{
    use HasAuthor;
    protected static string $table = 'sms_gateways';

    protected array $fillable = [
        'name',
        'provider_code',
        'api_url',
        'api_key',
        'api_secret',
        'sender_id',
        'is_active',
        'is_default',
        'priority',
        'configuration',
        'rate_limit_per_minute',
        'rate_limit_per_hour',
        'rate_limit_per_day',
        'rate_limit_enabled',
        'created_by',
        'updated_by'
    ];

    protected array $casts = [
        'is_active' => 'boolean',
        'is_default' => 'boolean',
        'rate_limit_enabled' => 'boolean',
        'rate_limit_per_minute' => 'integer',
        'rate_limit_per_hour' => 'integer',
        'rate_limit_per_day' => 'integer',
        'priority' => 'integer',
        'configuration' => 'json'
    ];

    // Encryption key from environment
    private static function getEncryptionKey(): string
    {
        return env('APP_KEY', 'default-encryption-key-change-me');
    }

    /**
     * Override __get to call accessors
     */
    public function __get($key)
    {
        // First check if there's an accessor method
        $method = 'get' . str_replace('_', '', ucwords($key, '_')) . 'Attribute';

        if (method_exists($this, $method)) {
            // Get raw value from attributes array or object property using reflection
            if (isset($this->attributes[$key])) {
                $value = $this->attributes[$key];
            } else {
                // Use reflection to get property without triggering __get recursion
                $reflection = new \ReflectionClass($this);
                if ($reflection->hasProperty($key)) {
                    $property = $reflection->getProperty($key);
                    $property->setAccessible(true);
                    $value = $property->getValue($this);
                } else {
                    $value = null;
                }
            }
            return $this->$method($value);
        }

        // Fallback to attributes
        return $this->attributes[$key] ?? parent::__get($key);
    }

    /**
     * Override __set to call mutators
     */
    public function __set($key, $value)
    {
        $method = 'set' . str_replace('_', '', ucwords($key, '_')) . 'Attribute';

        if (method_exists($this, $method)) {
            $this->$method($value);
        } else {
            $this->attributes[$key] = $value;
        }
    }

    /**
     * Override __isset to check if property exists
     */
    public function __isset($key): bool
    {
        // Check in attributes first
        if (isset($this->attributes[$key])) {
            return true;
        }

        // Check if property exists using reflection (for fetchObject properties)
        $reflection = new \ReflectionClass($this);
        if ($reflection->hasProperty($key)) {
            $property = $reflection->getProperty($key);
            $property->setAccessible(true);
            return $property->isInitialized($this) && $property->getValue($this) !== null;
        }

        return false;
    }

    /**
     * Encrypt sensitive data before saving
     */
    public function setApiKeyAttribute($value): void
    {
        if ($value) {
            $this->attributes['api_key'] = $this->encrypt($value);
        }
    }

    public function setApiSecretAttribute($value): void
    {
        if ($value) {
            $this->attributes['api_secret'] = $this->encrypt($value);
        }
    }

    /**
     * Decrypt sensitive data when retrieving
     */
    public function getApiKeyAttribute($value): ?string
    {
        return $value ? $this->decrypt($value) : null;
    }

    public function getApiSecretAttribute($value): ?string
    {
        return $value ? $this->decrypt($value) : null;
    }

    /**
     * Encrypt a value
     */
    private function encrypt(string $value): string
    {
        $key = self::getEncryptionKey();
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        $encrypted = openssl_encrypt($value, 'aes-256-cbc', $key, 0, $iv);
        return base64_encode($encrypted . '::' . $iv);
    }

    /**
     * Decrypt a value
     */
    private function decrypt(string $value): string
    {
        $key = self::getEncryptionKey();
        $decoded = base64_decode($value, true);

        // If decoding fails or doesn't contain delimiter, return original value (fallback for plain text)
        if ($decoded === false || strpos($decoded, '::') === false) {
            return $value;
        }

        $parts = explode('::', $decoded, 2);

        if (count($parts) !== 2) {
            return $value;
        }

        list($encrypted, $iv) = $parts;
        return openssl_decrypt($encrypted, 'aes-256-cbc', $key, 0, $iv) ?: $value;
    }

    /**
     * Check if this gateway is in Mock mode
     */
    public function isMockMode(): bool
    {
        // If no credentials or invalid credentials, it's in mock mode
        $hasValidApiKey = !empty($this->api_key) && strlen(trim($this->api_key)) > 10;
        $hasValidApiSecret = !empty($this->api_secret) && strlen(trim($this->api_secret)) > 10;

        return !$hasValidApiKey || !$hasValidApiSecret;
    }

    /**
     * Get the current mode (mock or production)
     */
    public function getMode(): string
    {
        return $this->isMockMode() ? 'mock' : 'production';
    }

    /**
     * Get all active gateways ordered by priority
     */
    public static function getActive(): array
    {
        return static::where('is_active', true)
            ->orderBy('priority', 'DESC')
            ->get();
    }

    /**
     * Get the default gateway
     */
    public static function getDefault(): ?self
    {
        return static::where('is_default', true)
            ->where('is_active', true)
            ->first();
    }

    /**
     * Set this gateway as default (and unset others)
     */
    public function setAsDefault(): bool
    {
        // Unset all other defaults
        static::where('is_default', 1)->update(['is_default' => 0]);

        // Set this one as default
        $this->is_default = 1;
        $this->save();
        return true;
    }

    /**
     * Test connection to gateway API
     */
    public function testConnection(): array
    {
        try {
            switch ($this->provider_code) {
                case 'orange_ci':
                    return $this->testOrangeCI();
                case 'infobip':
                    return $this->testInfobip();
                default:
                    return ['success' => false, 'message' => 'Unknown provider'];
            }
        } catch (\Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    private function testOrangeCI(): array
    {
        // Test Orange CI API connectivity
        $ch = curl_init($this->api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->api_key
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 || $httpCode === 401) {
            // 401 means auth failed but API is reachable
            return ['success' => true, 'message' => 'API reachable'];
        }

        return ['success' => false, 'message' => 'Connection failed'];
    }

    private function testInfobip(): array
    {
        // Test Infobip API connectivity
        $ch = curl_init($this->api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: App ' . $this->api_key,
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 || $httpCode === 401) {
            return ['success' => true, 'message' => 'API reachable'];
        }

        return ['success' => false, 'message' => 'Connection failed'];
    }
}
