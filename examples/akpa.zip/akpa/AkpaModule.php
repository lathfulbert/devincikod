<?php

namespace Modules\Akpa;

use App\Core\Module\AbstractModule;

class AkpaModule extends AbstractModule
{
    public function getRoutes(): array
    {
        return [
            ['GET', '/admin/akpa', ['Modules\Akpa\Controllers\BlogController', 'index']],
            ['GET', '/admin/akpa/create', ['Modules\Akpa\Controllers\BlogController', 'create']],
            ['POST', '/admin/akpa/store', ['Modules\Akpa\Controllers\BlogController', 'store']],
            ['GET', '/admin/akpa/{id}/edit', ['Modules\Akpa\Controllers\BlogController', 'edit']],
            ['POST', '/admin/akpa/{id}/update', ['Modules\Akpa\Controllers\BlogController', 'update']],
            ['POST', '/admin/akpa/{id}/delete', ['Modules\Akpa\Controllers\BlogController', 'delete']],
        ];
    }

    protected function getModulePath(): string
    {
        return __DIR__;
    }

    public function getMenuItems(): array
    {
        return [
            [
                'type' => 'dropdown',
                'title' => 'Akpa',
                'icon' => 'file-text',
                'children' => [
                    ['title' => 'Articles', 'url' => '/admin/akpa'],
                    ['title' => 'Ajouter', 'url' => '/admin/akpa/create'],
                ]
            ]
        ];
    }
}
